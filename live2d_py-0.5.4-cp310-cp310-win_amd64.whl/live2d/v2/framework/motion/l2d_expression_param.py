﻿class L2DExpressionParam:

    def __init__(self):
        self.id = ""
        self.type = -1
        self.value = None
