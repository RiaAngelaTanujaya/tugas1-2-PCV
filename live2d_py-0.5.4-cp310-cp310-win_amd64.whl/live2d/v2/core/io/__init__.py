﻿from .binary_reader import BinaryReader
from .iserializable import ISerializable
